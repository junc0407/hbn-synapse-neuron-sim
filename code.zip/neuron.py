import torch
import numpy as np
import os
import pandas as pd
from torchvision import datasets, transforms
from torch.utils.data import DataLoader
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score

# ============================
# 1. 基本设置
# ============================
output_dir = 'C:/Users/17415/Desktop/XJX/Code/Synapse_CIFRA_10/Results_Weight_read'
os.makedirs(output_dir, exist_ok=True)

# 加载量化后的模型
model_path = 'C:/Users/17415/Desktop/XJX/Code/Synapse_CIFRA_10/Results_VGG11_Xiaoshu_copy/cifar10_vgg11_2decimal.pth'
state_dict = torch.load(model_path, map_location='cpu')

# ============================
# 2. 计算准确率的函数
# ============================
# 数据预处理
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

# 加载CIFAR-10数据集
test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)
test_loader = DataLoader(test_dataset, batch_size=256, shuffle=False, num_workers=4)

# 定义VGG11模型（你原来的模型结构）
class VGG11(nn.Module):
    def __init__(self, num_classes=10):
        super(VGG11, self).__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Linear(512 * 1 * 1, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

# 计算准确率的函数
def calculate_accuracy(model, data_loader):
    model.eval()
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for data, target in data_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            _, predicted = torch.max(output, 1)
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(target.cpu().numpy())
    
    accuracy = accuracy_score(all_labels, all_preds)
    return accuracy


# ============================
# 3. 设置权重和偏置小于阈值的置零操作
# ============================
def set_weights_to_zero(model, threshold):
    num_zeroed = 0
    total_num = 0
    
    # 遍历每一层，找到权重（weight）和偏置（bias）
    for name, param in model.named_parameters():
        if 'weight' in name or 'bias' in name:
            # 获取当前参数的绝对值小于等于 threshold 的索引
            mask = torch.abs(param) <= threshold
            num_zeroed += mask.sum().item()  # 统计被置零的个数
            total_num += param.numel()  # 统计参数的总个数
            
            # 将这些小于等于 threshold 的值置为零，避免在计算图上直接修改
            param.data[mask] = 0  # 使用 `.data` 来修改参数
            
    zeroed_percentage = (num_zeroed / total_num) * 100
    return num_zeroed, total_num, zeroed_percentage


# ============================
# 4. 主逻辑
# ============================
if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = VGG11().to(device)

    # 加载原始的量化模型
    model.load_state_dict(state_dict)

    # 设置不同阈值的列表
    thresholds = [0, 0.02, 0.04, 0.06, 0.08, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.22, 0.24, 0.26, 0.28, 0.3,0.32,0.34,0.36,0.38, 0.4,0.42,0.44,0.46,0.48,0.5]


    # 存储每个阈值对应的结果
    results = []

    for threshold in thresholds:
        # 设置权重绝对值小于等于 threshold 的部分为零
        num_zeroed, total_num, zeroed_percentage = set_weights_to_zero(model, threshold)

        # 计算置零后模型的准确率
        zeroed_accuracy = calculate_accuracy(model, test_loader)

        # 输出当前阈值的结果到终端
        print(f"阈值: {threshold}, 准确率: {zeroed_accuracy:.4f}, 置零权重数: {num_zeroed}, 总参数数: {total_num}, 置零比例: {zeroed_percentage:.2f}%")

        # 保存当前阈值下的结果
        results.append({
            'threshold': threshold,
            'zeroed_accuracy': zeroed_accuracy,
            'num_zeroed': num_zeroed,
            'total_num': total_num,
            'zeroed_percentage': zeroed_percentage
        })

    # 打印调试信息，确认结果是否有数据
    print(f"Results: {results}")

    # 保存结果到 CSV 文件
    try:
        df_results = pd.DataFrame(results)
        df_results.to_csv(os.path.join(output_dir, 'threshold_results.csv'), index=False)
        print(f"所有阈值测试完成，结果已保存到 {os.path.join(output_dir, 'threshold_results.csv')}")
    except Exception as e:
        print(f"保存结果时发生错误: {e}")
