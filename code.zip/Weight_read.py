import pandas as pd
import torch
import numpy as np
import os

# 创建结果目录
output_dir = './Results_Weight_read'
os.makedirs(output_dir, exist_ok=True)

# 加载模型参数
model_path = './Results_VGG11_Xiaoshu_copy/cifar10_vgg11_2decimal.pth'
state_dict = torch.load(model_path, map_location='cpu')

def get_formatted_stats(state_dict, decimal_places=None):
    """获取模型权重和偏置的统计信息（最大值、最小值、唯一值数量）"""
    all_values = []
    
    for layer_name, params in state_dict.items():
        # 只统计权重（weight）和偏置（bias）
        if layer_name.endswith('weight') or layer_name.endswith('bias'):
            numpy_array = params.numpy().flatten()
            if decimal_places is not None:
                numpy_array = np.round(numpy_array, decimals=decimal_places)
            all_values.extend(numpy_array.tolist())
    
    if not all_values:  # 如果没有权重或偏置数据
        return {
            'max': None,
            'min': None,
            'unique_count': 0
        }
    
    all_values = np.array(all_values)
    
    return {
        'max': np.max(all_values),
        'min': np.min(all_values),
        'unique_count': len(np.unique(all_values))
    }

# 保存所有层权重为CSV文件（可选）
print("开始保存CSV文件...")
for layer_name, params in state_dict.items():
    # 只处理权重和偏置
    #if layer_name.endswith('weight') or layer_name.endswith('bias'):
    if layer_name.endswith('weight'):
        safe_layer_name = layer_name.replace('.', '_').replace(' ', '_')
        csv_path = f"{output_dir}/{safe_layer_name}.csv"
        
        # 将权重数据转为DataFrame并保存
        pd.DataFrame(params.numpy().reshape(-1, 1), columns=[layer_name]) \
          .to_csv(csv_path, index=False)
        print(f"已保存: {csv_path}")

# 输出统计信息
stats = get_formatted_stats(state_dict, decimal_places=2)

print("\n权重和偏置统计信息（合并统计）:")
print(f"最大值: {stats['max']:.1f}" if stats['max'] is not None else "无数据")
print(f"最小值: {stats['min']:.1f}" if stats['min'] is not None else "无数据")
print(f"唯一值数量: {stats['unique_count']}")