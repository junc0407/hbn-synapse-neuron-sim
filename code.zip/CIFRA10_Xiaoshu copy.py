# VGG11 for CIFAR-10: 生成混淆矩阵，训练准确率曲线
import torch
import numpy as np
from matplotlib import pyplot as plt
from torch.utils.data import DataLoader
from torchvision import transforms
from torchvision import datasets
import torch.nn.functional as F
import time
import pandas as pd
from sklearn.metrics import confusion_matrix
import seaborn as sns
import os
import torch.nn as nn
import copy


"""
卷积运算 使用cifra-10数据集，和10-4，11类似的，只是这里：1.输出训练轮的acc 2.模型上使用torch.nn.Sequential
添加了混淆矩阵可视化并保存为Excel的功能
添加了参数四舍五入保留1位、2位和3位精度时的训练情况
"""
# Super parameter ------------------------------------------------------------------------------------
batch_size = 256
learning_rate = 0.005  # 降低学习率
momentum = 0.9         # 增加momentum
EPOCH = 200            # 增加训练轮次
num_workers = 8        # 根据i5-13400F的12线程设置（建议4*GPU数量，这里取6）
weight_decay = 1e-3    # 添加权重衰减

# 创建结果目录
os.makedirs('./Results_VGG11_Xiaoshu_copy', exist_ok=True)

# 数据预处理（增强数据增强）
transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),  # 新增
    transforms.RandomRotation(15),  # 新增
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])
transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

# 加载CIFAR-10数据集
train_dataset = datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
test_dataset = datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True,
                         num_workers=num_workers, pin_memory=False, persistent_workers=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False,
                         num_workers=num_workers, pin_memory=False, persistent_workers=True)

# 定义改进的VGG11网络
class VGG11(nn.Module):
    def __init__(self, num_classes=10):
        super(VGG11, self).__init__()
        self.features = nn.Sequential(
            # Block 1
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            # Block 2
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            # Block 3
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            # Block 4
            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
            
            # Block 5
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),  # 新增BatchNorm
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )
        self.classifier = nn.Sequential(
            nn.Linear(512 * 1 * 1, 4096),  # 保持原尺寸
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, num_classes),
        )
        
        # 初始化权重
        self._initialize_weights()

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x
    
    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.constant_(m.bias, 0)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = VGG11().to(device)

# 构造损失函数和优化器 ------------------------------------------------------------------------------
criterion = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)  # 使用AdamW优化器
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=30, gamma=0.1)  # 添加学习率调度

# 训练和测试函数 --------------------------------------------------------------------------------------
def train(epoch):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for batch_idx, data in enumerate(train_loader, 0):
        inputs, target = data
        inputs, target = inputs.to(device), target.to(device)
        optimizer.zero_grad()
        
        outputs = model(inputs)
        loss = criterion(outputs, target)
        loss.backward()
        
        # 梯度裁剪
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        
        optimizer.step()
        
        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += target.size(0)
        correct += predicted.eq(target).sum().item()
        
        if batch_idx % 50 == 0:
            print(f'Train Epoch: {epoch} [{batch_idx * len(inputs)}/{len(train_loader.dataset)} '
                  f'({100. * batch_idx / len(train_loader):.0f}%)]\tLoss: {loss.item():.6f}')
    
    train_loss = running_loss / len(train_loader)
    train_acc = correct / total
    print(f'Train Epoch: {epoch}\tAverage Loss: {train_loss:.4f}\tAccuracy: {100 * train_acc:.2f}%')
    
    return train_loss, train_acc

def generate_confusion_matrix(true_labels, pred_labels, normalize=None, suffix=""):
    cm = confusion_matrix(true_labels, pred_labels)

    if normalize == 'true':
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt = '.2f'
        vmin, vmax = 0, 1
    elif normalize == 'pred':
        cm = cm.astype('float') / cm.sum(axis=0)
        fmt = '.2f'
        vmin, vmax = 0, 1
    else:
        fmt = 'd'
        vmin = None
        vmax = None
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues', 
                xticklabels=range(10), yticklabels=range(10),
                vmin=vmin, vmax=vmax)
    plt.xlabel('Predicted labels')
    plt.ylabel('True labels')
    title = 'Confusion Matrix'
    if suffix:
        title += f' ({suffix})'
    if normalize == 'true':
        title += ' (Normalized by True)'
    elif normalize == 'pred':
        title += ' (Normalized by Pred)'
    plt.title(title)
    
    # 构建文件名
    filename = f'confusion_matrix{suffix}'
    if normalize:
        filename += f'_{normalize}'
    plt.savefig(f'./Results_VGG11_Xiaoshu_copy/{filename}.png')
    plt.close()
    print(f"Confusion matrix visualization saved as {filename}.png")
    
    # 将混淆矩阵保存为Excel文件
    cm_df = pd.DataFrame(cm, 
                         index=[f'True_{i}' for i in range(10)],
                         columns=[f'Pred_{i}' for i in range(10)])
    
    # 添加行和列的总和
    cm_df['True_Total'] = cm_df.sum(axis=1)
    cm_df.loc['Pred_Total'] = cm_df.sum(axis=0)
    
    # 保存到Excel
    cm_df.to_excel(f'./Results_VGG11_Xiaoshu_copy/{filename}.xlsx')
    print(f"Confusion matrix saved as {filename}.xlsx")

def test_with_rounded_params(model, decimal_places):
    # 创建模型的深拷贝以避免修改原始模型
    rounded_model = copy.deepcopy(model)
    
    # 对模型参数进行四舍五入
    with torch.no_grad():
        for param in rounded_model.parameters():
            #param.data = torch.round(param.data*(10**decimal_places))/(10**decimal_places)
            param.data = torch.round(param.data*(2*5**decimal_places))/(2*5**decimal_places)
    
    # 保存四舍五入后的模型
    if epoch == EPOCH - 1:  # 只在最后一个epoch保存
        torch.save(rounded_model.state_dict(), f'./Results_VGG11_Xiaoshu_copy/cifar10_vgg11_{decimal_places}decimal.pth')
        print(f"Saved model with {decimal_places} decimal places to cifar10_vgg11_{decimal_places}decimal.pth")
    
    # 测试四舍五入后的模型
    rounded_model.eval()
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    test_loss = 0.0
    
    with torch.no_grad():
        for data in test_loader:
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            outputs = rounded_model(images)
            loss = criterion(outputs, labels)
            test_loss += loss.item()
            
            _, predicted = torch.max(outputs.data, dim=1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    test_loss /= len(test_loader)
    acc = correct / total
    
    # 只在最后一个epoch生成混淆矩阵
    if epoch == EPOCH - 1:
        suffix = f"_{decimal_places}decimal"
        # 生成原始计数矩阵
        generate_confusion_matrix(all_labels, all_preds, suffix=suffix)
        # 生成按真实标签归一化的矩阵
        generate_confusion_matrix(all_labels, all_preds, normalize='true', suffix=suffix)
        # 生成按预测标签归一化的矩阵
        generate_confusion_matrix(all_labels, all_preds, normalize='pred', suffix=suffix)
    
    return test_loss, acc

def test():
    model.eval()
    correct = 0
    total = 0
    all_preds = []
    all_labels = []
    test_loss = 0.0
    
    with torch.no_grad():
        for data in test_loader:
            images, labels = data
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            test_loss += loss.item()
            
            _, predicted = torch.max(outputs.data, dim=1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            
            all_preds.extend(predicted.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    test_loss /= len(test_loader)
    acc = correct / total
    
    # 测试不同小数位数的准确率
    test_loss_1d, acc_1d = test_with_rounded_params(model, 1)
    test_loss_2d, acc_2d = test_with_rounded_params(model, 2)
    test_loss_3d, acc_3d = test_with_rounded_params(model, 3)
    
    # 只在最后一个epoch生成原始模型的混淆矩阵
    if epoch == EPOCH - 1:
        # 生成原始计数矩阵
        generate_confusion_matrix(all_labels, all_preds, suffix="original")
        # 生成按真实标签归一化的矩阵
        generate_confusion_matrix(all_labels, all_preds, normalize='true', suffix="original")
        # 生成按预测标签归一化的矩阵
        generate_confusion_matrix(all_labels, all_preds, normalize='pred', suffix="original")
    
    print(f'Test set: Average loss: {test_loss:.4f}\tAccuracy: {100 * acc:.2f}%')
    print(f'  With 3 decimal places: Loss: {test_loss_3d:.4f}\tAccuracy: {100 * acc_3d:.2f}%')
    print(f'  With 2 decimal places: Loss: {test_loss_2d:.4f}\tAccuracy: {100 * acc_2d:.2f}%')
    print(f'  With 1 decimal place: Loss: {test_loss_1d:.4f}\tAccuracy: {100 * acc_1d:.2f}%')
    
    return test_loss, acc, test_loss_1d, acc_1d, test_loss_2d, acc_2d, test_loss_3d, acc_3d

# 开始训练和测试 --------------------------------------------------------------------------------------
if __name__ == '__main__':
    print(f"Using device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
    acc_list_test = []
    loss_list_test = []
    acc_list_train = []
    loss_list_train = []
    
    # 添加不同小数精度的记录
    acc_list_1decimal = []
    loss_list_1decimal = []
    acc_list_2decimal = []
    loss_list_2decimal = []
    acc_list_3decimal = []
    loss_list_3decimal = []
    
    start_time = time.time()
    
    for epoch in range(EPOCH):
        epoch_start = time.time()
        
        train_loss, train_acc = train(epoch)
        test_loss, test_acc, test_loss_1d, acc_1d, test_loss_2d, acc_2d, test_loss_3d, acc_3d = test()
        
        # 更新学习率
        scheduler.step()
        
        epoch_time = time.time() - epoch_start
        print(f'Epoch {epoch+1} took {epoch_time:.2f} seconds')
        
        # 记录训练和测试指标
        acc_list_test.append(test_acc)
        loss_list_test.append(test_loss)
        acc_list_train.append(train_acc)
        loss_list_train.append(train_loss)
        
        # 记录不同小数精度的指标
        acc_list_1decimal.append(acc_1d)
        loss_list_1decimal.append(test_loss_1d)
        acc_list_2decimal.append(acc_2d)
        loss_list_2decimal.append(test_loss_2d)
        acc_list_3decimal.append(acc_3d)
        loss_list_3decimal.append(test_loss_3d)
    
    total_time = time.time() - start_time
    print(f'Total training time: {total_time/60:.2f} minutes')
    
    # 绘制准确率曲线
    plt.figure(figsize=(12, 10))
    plt.subplot(2, 2, 1)
    plt.plot(acc_list_train, label='Train Accuracy')
    plt.plot(acc_list_test, label='Test Accuracy')
    plt.plot(acc_list_1decimal, label='1 Decimal Place')
    plt.plot(acc_list_2decimal, label='2 Decimal Places')
    plt.plot(acc_list_3decimal, label='3 Decimal Places')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend()
    plt.title('Accuracy Curves')
    
    # 绘制损失曲线
    plt.subplot(2, 2, 2)
    plt.plot(loss_list_train, label='Train Loss')
    plt.plot(loss_list_test, label='Test Loss')
    plt.plot(loss_list_1decimal, label='1 Decimal Place')
    plt.plot(loss_list_2decimal, label='2 Decimal Places')
    plt.plot(loss_list_3decimal, label='3 Decimal Places')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Loss Curves')
    
    # 绘制不同小数精度的准确率对比
    plt.subplot(2, 2, 3)
    plt.plot(acc_list_1decimal, label='1 Decimal Place')
    plt.plot(acc_list_2decimal, label='2 Decimal Places')
    plt.plot(acc_list_3decimal, label='3 Decimal Places')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend()
    plt.title('Accuracy with Different Parameter Precision')
    
    # 绘制不同小数精度的损失对比
    plt.subplot(2, 2, 4)
    plt.plot(loss_list_1decimal, label='1 Decimal Place')
    plt.plot(loss_list_2decimal, label='2 Decimal Places')
    plt.plot(loss_list_3decimal, label='3 Decimal Places')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.title('Loss with Different Parameter Precision')
    
    plt.tight_layout()
    plt.savefig('./Results_VGG11_Xiaoshu_copy/training_curves.png')
    plt.show()
    
    # 保存准确率数据到Excel
    acc_df = pd.DataFrame({
        'Epoch': range(1, EPOCH+1),
        'Train_Accuracy': acc_list_train,
        'Test_Accuracy': acc_list_test,
        'Accuracy_1decimal': acc_list_1decimal,
        'Accuracy_2decimal': acc_list_2decimal,
        'Accuracy_3decimal': acc_list_3decimal,
        'Train_Loss': loss_list_train,
        'Test_Loss': loss_list_test,
        'Loss_1decimal': loss_list_1decimal,
        'Loss_2decimal': loss_list_2decimal,
        'Loss_3decimal': loss_list_3decimal
    })
    acc_df.to_excel('./Results_VGG11_Xiaoshu_copy/training_metrics.xlsx', index=False)
    print("Training metrics saved as training_metrics.xlsx")
    
    # 保存模型
    torch.save(model.state_dict(), './Results_VGG11_Xiaoshu_copy/cifar10_vgg11.pth')
    print("Model saved as cifar10_vgg11.pth")