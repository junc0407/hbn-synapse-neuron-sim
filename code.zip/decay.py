# ============================================================
# Original-style 1-bit to 8-bit quantization evaluation
# Mapping rule:
#     original index 1 -> 6-bit
#     original index 2 -> 8-bit
#
# Therefore:
#     bit = 2 * original_index + 4
#     original_index = (bit - 4) / 2
#
# Original quantization formula:
#     param_q = round(param * scale) / scale
#     scale = 2 * 5 ** original_index
# ============================================================

import os
import copy
import torch
import torch.nn as nn
import pandas as pd
import matplotlib.pyplot as plt

from torchvision import datasets, transforms
from torch.utils.data import DataLoader


# ============================================================
# 1. Basic settings
# ============================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(
    BASE_DIR,
    "Results_VGG11_Xiaoshu_copy",
    "cifar10_vgg11.pth"
)

OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "Results_OriginalStyle_1bit_to_8bit"
)

os.makedirs(OUTPUT_DIR, exist_ok=True)

BATCH_SIZE = 256
NUM_WORKERS = 0
BITS_LIST = list(range(1, 9))

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print(f"Using device: {device}")
print(f"Model path: {MODEL_PATH}")
print(f"Output dir: {OUTPUT_DIR}")


# ============================================================
# 2. CIFAR-10 test dataset
# ============================================================

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(
        (0.4914, 0.4822, 0.4465),
        (0.2023, 0.1994, 0.2010)
    ),
])

test_dataset = datasets.CIFAR10(
    root=os.path.join(BASE_DIR, "data"),
    train=False,
    download=True,
    transform=transform_test
)

test_loader = DataLoader(
    test_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=NUM_WORKERS,
    pin_memory=torch.cuda.is_available()
)


# ============================================================
# 3. Define VGG11 model
# Must be exactly the same as your training code
# ============================================================

class VGG11(nn.Module):
    def __init__(self, num_classes=10):
        super(VGG11, self).__init__()

        self.features = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.Conv2d(256, 256, kernel_size=3, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(256, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),

            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.Conv2d(512, 512, kernel_size=3, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2),
        )

        self.classifier = nn.Sequential(
            nn.Linear(512 * 1 * 1, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, 4096),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(4096, num_classes),
        )

    def forward(self, x):
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


# ============================================================
# 4. Evaluation function
# ============================================================

def evaluate_model(model, data_loader):
    model.eval()

    correct = 0
    total = 0
    total_loss = 0.0

    criterion = nn.CrossEntropyLoss()

    with torch.no_grad():
        for images, labels in data_loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            _, preds = torch.max(outputs, dim=1)

            total += labels.size(0)
            correct += (preds == labels).sum().item()
            total_loss += loss.item()

    accuracy = correct / total
    avg_loss = total_loss / len(data_loader)

    return avg_loss, accuracy


# ============================================================
# 5. Original-style bit mapping and quantization
# ============================================================

def bit_to_original_index(bit):
    """
    According to your definition:
        original index 1 -> 6-bit
        original index 2 -> 8-bit

    Therefore:
        bit = 2 * original_index + 4
        original_index = (bit - 4) / 2
    """

    return (bit - 4) / 2.0


def bit_to_original_scale_and_step(bit):
    """
    Original quantization:
        scale = 2 * 5 ** original_index
        step = 1 / scale
    """

    original_index = bit_to_original_index(bit)
    scale = 2.0 * (5.0 ** original_index)
    step = 1.0 / scale

    return original_index, scale, step


def original_style_quantize_model(model, bit):
    """
    Quantize all trainable parameters using the original code style:

        param_q = round(param * scale) / scale

    This is consistent with:
        for param in rounded_model.parameters():
            param.data = torch.round(param.data * scale) / scale

    All trainable parameters share the same scale, so this is global fixed-step quantization.
    """

    quantized_model = copy.deepcopy(model)
    quantized_model.eval()

    original_index, scale, step = bit_to_original_scale_and_step(bit)

    with torch.no_grad():
        for param in quantized_model.parameters():
            param.data = torch.round(param.data * scale) / scale

    return quantized_model, original_index, scale, step


def count_unique_trainable_values(model):
    all_values = []

    with torch.no_grad():
        for param in model.parameters():
            all_values.append(param.data.detach().cpu().flatten())

    all_values = torch.cat(all_values)
    return torch.unique(all_values).numel()


# ============================================================
# 6. Main
# ============================================================

if __name__ == "__main__":

    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"Model file not found: {MODEL_PATH}")

    # Load full-precision model
    model_fp = VGG11().to(device)
    state_dict = torch.load(MODEL_PATH, map_location=device)
    model_fp.load_state_dict(state_dict)
    model_fp.eval()

    # Evaluate FP32
    fp_loss, fp_acc = evaluate_model(model_fp, test_loader)
    fp_unique = count_unique_trainable_values(model_fp)

    print("=" * 80)
    print(f"FP32 | loss: {fp_loss:.4f} | accuracy: {fp_acc:.4f} | accuracy_percent: {fp_acc * 100:.2f}%")
    print("=" * 80)

    results = []

    results.append({
        "bit": "FP32",
        "original_index": None,
        "scale": None,
        "quantization_step": None,
        "loss": fp_loss,
        "accuracy": fp_acc,
        "accuracy_percent": fp_acc * 100,
        "accuracy_drop_percent": 0.0,
        "unique_values": fp_unique,
        "quantization_method": "full_precision"
    })

    # Evaluate 1-bit to 8-bit
    for bit in BITS_LIST:
        quantized_model, original_index, scale, step = original_style_quantize_model(
            model_fp,
            bit
        )

        quantized_model = quantized_model.to(device)

        loss, acc = evaluate_model(quantized_model, test_loader)
        unique_values = count_unique_trainable_values(quantized_model)
        acc_drop = (fp_acc - acc) * 100

        print(
            f"{bit}-bit | "
            f"original_index: {original_index:.2f} | "
            f"scale: {scale:.6f} | "
            f"step: {step:.6f} | "
            f"loss: {loss:.4f} | "
            f"accuracy: {acc:.4f} | "
            f"accuracy_percent: {acc * 100:.2f}% | "
            f"accuracy_drop: {acc_drop:.2f}% | "
            f"unique_values: {unique_values}"
        )

        results.append({
            "bit": bit,
            "original_index": original_index,
            "scale": scale,
            "quantization_step": step,
            "loss": loss,
            "accuracy": acc,
            "accuracy_percent": acc * 100,
            "accuracy_drop_percent": acc_drop,
            "unique_values": unique_values,
            "quantization_method": "original_style_global_fixed_step"
        })

    # Save results
    df = pd.DataFrame(results)

    csv_path = os.path.join(
        OUTPUT_DIR,
        "vgg11_original_style_1bit_to_8bit_accuracy.csv"
    )

    excel_path = os.path.join(
        OUTPUT_DIR,
        "vgg11_original_style_1bit_to_8bit_accuracy.xlsx"
    )

    df.to_csv(csv_path, index=False)
    df.to_excel(excel_path, index=False)

    print("\nResults saved:")
    print(csv_path)
    print(excel_path)

    # Plot
    plot_df = df[df["bit"] != "FP32"].copy()
    plot_df["bit"] = plot_df["bit"].astype(int)

    plt.figure(figsize=(8, 6))
    plt.plot(
        plot_df["bit"],
        plot_df["accuracy_percent"],
        marker="o",
        label="Original-style quantized model"
    )

    plt.axhline(
        fp_acc * 100,
        linestyle="--",
        label="FP32"
    )

    plt.xlabel("Weight Precision (bit)")
    plt.ylabel("Test Accuracy (%)")
    plt.title("Original-style 1-bit to 8-bit Quantization on CIFAR-10")
    plt.xticks(BITS_LIST)
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.legend()
    plt.tight_layout()

    fig_path = os.path.join(
        OUTPUT_DIR,
        "accuracy_vs_original_style_1bit_to_8bit.png"
    )

    plt.savefig(fig_path, dpi=300)
    plt.close()

    print(f"Figure saved: {fig_path}")